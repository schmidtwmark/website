//
//  TurtleConsoleView.swift
//  StudentCodeTemplate
//
//  Created by Mark Schmidt on 11/16/24.
//

import SwiftUI
import SpriteKit

enum Speed : CGFloat, CaseIterable, Identifiable {
    var id: CGFloat {
        self.rawValue
    }
    
    case slow = 0.5
    case normal = 1.0
    case fast = 2.0
    
    var title: String {
        switch self {
            case .slow: return "Slow"
            case .normal: return "Normal"
            case .fast: return "Fast"
        }
    }
    
    var systemImage: String {
        switch self {
        case .slow: return "tortoise.fill"
        case .normal: return "figure.run"
        case .fast: return "hare.fill"
        }
    }
}

extension Double {
    var formattedToTwoDecimals: String {
        String(format: "%.2f", self)
    }
}

extension CGFloat {
    var formattedToTwoDecimals: String {
        String(format: "%.2f", self)
    }
}


public struct TurtleConsoleView: ConsoleView {
    
    public init(console: TurtleConsole) {
        self.console = console 
    }
    
    @State var showButtons: Bool = false
    @State var sceneSpeed: Speed = .normal
    
    @ObservedObject var console: TurtleConsole
    @Environment(\.colorScheme) var colorScheme: ColorScheme
    
    func normalizeRotation(radians: Double) -> Double {
        let degrees = radians * 180 / .pi
        return (degrees.truncatingRemainder(dividingBy: 360) + 360).truncatingRemainder(dividingBy: 360)
    }
    
    @ViewBuilder
    func turtleDebugView(turtle: Turtle) -> some View{
        let rotationString = normalizeRotation(radians: turtle.zRotation).formattedToTwoDecimals
        VStack(alignment: .leading) {
            Text("(\(turtle.position.x.formattedToTwoDecimals) \(turtle.position.y.formattedToTwoDecimals))")
            Text("\(rotationString)°")
        }
        .foregroundStyle(Color(uiColor: turtle.color))
        .padding(3.0)
        .background(RoundedRectangle(cornerRadius: 5.0).fill(Color.gray.opacity(0.1)))
        .overlay(
            RoundedRectangle(cornerRadius: 5.0)
                .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
    }
    
    public var body: some View {
        SpriteView(scene: console.scene)
            .onTapGesture {
                withAnimation {
                    showButtons.toggle()
                }
            }
            .onChange(of: colorScheme, {
                console.updateBackground(colorScheme)
            })
            .overlay(alignment: .bottomLeading) {
                if showButtons {
                    VStack(alignment: .leading, spacing: 5) {
                        ForEach(console.scene.turtles) { turtle in
                            turtleDebugView(turtle: turtle)
                        }
                    }
                    .padding()
                }
            }
            .overlay(alignment: .bottomTrailing) {
                if showButtons {
                    HStack(spacing: 10) {
                        ForEach(Speed.allCases) { speed in
                            Button(action: {
                                withAnimation {
                                    console.scene.speed = speed.rawValue
                                    sceneSpeed = speed
                                }
                            }) {
                                Image(systemName: speed.systemImage)
                                    .font(.title2)
                                    .padding(12)
                                    .background(
                                        sceneSpeed == speed
                                        ? Color.blue
                                        : Color.gray.opacity(0.2)
                                    )
                                    .foregroundColor(sceneSpeed == speed ? .white : .primary)
                                    .clipShape(Capsule())
                            }
                        }
                    }
                    .padding()
                    .background(Capsule().fill(Color.gray.opacity(0.1)))
                    .overlay(
                        Capsule()
                            .stroke(Color.gray.opacity(0.3), lineWidth: 1)
                        )
                    .padding()
                }
            }
            .overlay(alignment: .topTrailing) {
                Button {
                        console.scene.lockCamera()
                    } label: {
                        Image(systemName: "camera.fill")
                            .font(.title2)
                            .padding(12)
                            .background(
                                Color.gray.opacity(0.2)
                            )
                            .foregroundColor(.white)
                            .clipShape(Capsule())

                    }
                    .padding()
                    .opacity(console.scene.showCameraLock ? 1 : 0)
                    .animation(.easeInOut(duration: 0.5), value: console.scene.showCameraLock)
                    
            }
    }
}
