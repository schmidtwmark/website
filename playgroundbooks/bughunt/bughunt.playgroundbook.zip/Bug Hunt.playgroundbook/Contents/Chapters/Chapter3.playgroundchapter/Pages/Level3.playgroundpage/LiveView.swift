import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = RobotLiveViewController(level: .ascii("""
#####
#v..#
#.#.#
#A#.#
#.#.#
#*#a#
#####
"""), par: 22)
