// This page is reading only, so it has no live view.
