/*:
 # Driving the Robot
 On every level, write code that drives the robot to the flag. Type commands on the level's page, then press **Run My Code**. The robot follows them one at a time, in order:

 ```
 robot.turnRight()
 robot.forward()
 robot.forward()
 ```

 ## What you'll find on the map
 - **Walls.** Driving into a wall, or off the map, is game over.
 - **Keys and doors.** A door stays locked until the robot picks up the key of the same color.
 - **Enemies.** They bounce back and forth, one square every time the robot steps, turns, or waits. Don't get caught!
 - **Lasers.** They blink on and off, and each color has its own timing. Only walk through when they're off.
 - **Teleporters.** Step on one and the robot jumps to its matching teleporter.

 ## Par
 Each level has a par: the number of moves a good solution takes. Every step, turn, and wait counts as a move. Reach the flag in par or fewer to get a **Perfect!**

 When you finish, try **Custom Level** to design a level of your own.

 ## Commands
 - `robot.forward()` moves one square forward
 - `robot.turnRight()` turns 90° to the right
 - `robot.turnLeft()` turns 90° to the left
 - `robot.wait()` waits one turn. Lasers and enemies keep moving.
 */
