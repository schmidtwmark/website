import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = RobotLiveViewController(level: .ascii("""
#######
#v..###
###.###
#R....#
###.###
#..*..#
#######
"""), par: 9)
