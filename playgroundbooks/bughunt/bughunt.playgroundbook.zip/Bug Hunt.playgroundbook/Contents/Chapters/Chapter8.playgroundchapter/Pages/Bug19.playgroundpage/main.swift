//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 19: The Spiral
 ## What it should do
 The robot starts in the middle of a spiral. It should follow the spiral for **6** sides, turning right after each one, then turn around and step into the little room with the flag.
 */

var sides = 0
while sides < 6 {
    while robot.facingEmptySpace() {
        robot.forward()
    }
    robot.turnRight()
}
// Turn around and step into the flag's room
robot.turnLeft()
robot.turnLeft()
robot.forward()
