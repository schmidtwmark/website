/*:
 # Hints
 One hint for each bug. Hunt for a few minutes before you look!

 ## Bug 1
 Swift cares about capital letters. Compare how the variable is spelled where it's made and where it's used.

 ## Bug 2
 Watch which way the robot turns. Point your arm the way it should go.

 ## Bug 3
 Every piece of text needs a `"` at the start and another at the end. Check each line.

 ## Bug 4
 Read the red error out loud. What's the difference between `let` and `var`?

 ## Bug 5
 Count the `{` and the `}`. There should be the same number of each.

 ## Bug 6
 Read the first red error. Can a variable's name have a space in it?

 ## Bug 7
 Compare the two `for` loops. Count the dots.

 ## Bug 8
 Type LEFT. Which line prints? Now read the text inside the quotes one letter at a time.

 ## Bug 9
 Count how many times each loop runs. Count out loud: 0, 1, 2...

 ## Bug 10
 Read the red error. What word is missing after `else`?

 ## Bug 11
 Compare the first loop with the second one. Which brackets does a loop use? Which ones does a command like `robot.turnRight` use?

 ## Bug 12
 Type SWORD. Why does the `else` run too? Which `if` does that `else` belong to?

 ## Bug 13
 Look at the spaces around each `=` and `==`. Is there a space on both sides?

 ## Bug 14
 Which lines are inside the loop's `{ }`? Those are the only ones that repeat.

 ## Bug 15
 Read every red error, not just the first one. How do you ask "is it equal?" in Swift?

 ## Bug 16
 Which lines are inside the `{ }`? Those are the lines that repeat.

 ## Bug 17
 `console.write` shows text. `console.read` shows text and then waits for you to type. Which one does each line need?

 ## Bug 18
 Count the `{` and the `}`. What should come right before `else`?

 ## Bug 19
 If the robot never stops, tap Stop. Which variable should go up by 1 each time the robot finishes a side?

 ## Bug 20
 Type RIGHT. Why does it ask about FIRE? Which lines are inside the LEFT block's `{ }`?

 ## Bug 21
 Where is `weapon` made? Can a line outside those `{ }` use it?

 ## Bug 22
 Type LEFT, then FIRE. Which variable holds FIRE? Which variable does the inside `if` check? Look for a yellow warning.

 ## Bug 23
 Find every place the program uses `jumpHurdle()`.

 ## Bug 24
 Fix one red error at a time: what does every `if` line end with? Then compare how `bearChoice` is spelled where it's made and where it's used.

 ## Bug 25
 Fix the red error first. Then try every door: RED, GREEN, BLUE, and PURPLE. Does each one print only its own ending?

 ## Bug 26
 Type RIGHT: nothing happens! Which `if` does the beach `else` belong to? Follow the `{` and `}` with your finger.

 ## Bug 27
 The first stair works. What is `steps` when the robot starts the second stair?

 ## Bug 28
 Type LEFT. Why does it still say STICK? How many variables named `weapon` are there? Read the yellow warning.

 ## Bug 29
 How many times does an `if` run? How long does a laser stay on?

 ## Bug 30
 Type MOTH. Why does it ask again? What would make `unlocked == false` stop being true?
 */
