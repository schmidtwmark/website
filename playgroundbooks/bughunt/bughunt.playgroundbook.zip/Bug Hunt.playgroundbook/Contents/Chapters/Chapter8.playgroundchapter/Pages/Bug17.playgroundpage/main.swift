//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 17
 ## What it should do
 Welcome you, ask for your name, then wish you luck. If you type `sam`, the last line should be:

 ```
 Good luck, sam!
 ```

 You should only have to type **once**. This one has **two** bugs!
 */

console.read("Welcome to the Dragon Cave!")
let name = console.write("What is your name, hero?")
console.write("Good luck, " + name + "!")
