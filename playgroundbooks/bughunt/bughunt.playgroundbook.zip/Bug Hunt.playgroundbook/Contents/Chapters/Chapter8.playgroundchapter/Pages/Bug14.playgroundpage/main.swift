//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 14: Three Sides
 ## What it should do
 Drive 3 squares and turn right. Do that for each side until you reach the flag.
 */

var sides = 0
while sides < 3 {
    robot.forward()
    robot.forward()
    robot.forward()
    sides = sides + 1
}
robot.turnRight()
