//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 29
 ## What it should do
 **Challenge bug:** this one is extra tricky.

 Walk down the hall to the flag without getting zapped. Before each step, wait until the laser in front of the robot is off.
 */

while robot.facingEmptySpace() {
    if robot.laserAhead() {
        robot.wait()
    }
    robot.forward()
}
