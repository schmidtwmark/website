//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 15
 ## What it should do
 Type `LEFT` and you cross a bridge. Type anything else and you climb a mountain.
 */

let path = console.read("Choose LEFT or RIGHT")
if path = "LEFT" {
    console.write("You cross a rickety bridge.")
} else {
    console.write("You climb a tall mountain.")
}
