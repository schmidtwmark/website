//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 3: Missing Quote
 ## What it should do
 Print three lines:

 ```
 You wake up in a dark cave.
 You see a light in the distance!
 You walk toward it.
 ```
 */

console.write("You wake up in a dark cave.")
console.write("You see a light in the distance!)
console.write("You walk toward it.")
