//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 2: Wrong Way
 ## What it should do
 Drive 4 squares, turn toward the flag, and drive 3 squares to reach it.
 */

robot.forward()
robot.forward()
robot.forward()
robot.forward()
robot.turnRight()
robot.forward()
robot.forward()
robot.forward()
