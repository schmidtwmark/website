//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 5: Extra Brace
 ## What it should do
 Type `APPLE` or `COOKIE` and get a message about your snack.
 */

let snack = console.read("Choose APPLE or COOKIE")
if snack == "APPLE" {
    console.write("Crunchy and healthy!")
} else {
    console.write("Delicious, but now you want another one.")
}
}
