//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 9
 ## What it should do
 Drive 5 squares, turn right, and drive 3 squares to the flag.
 */

for _ in 0...5 {
    robot.forward()
}
robot.turnRight()
for _ in 1...3 {
    robot.forward()
}
