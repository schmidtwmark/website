import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = RobotLiveViewController(level: .ascii("""
###############
#####1###6#####
#>...1...6...*#
#####1###6#####
###############
###############
###############
"""))
