//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 21
 ## What it should do
 Type `LEFT`, then `SWORD` or `BOW`. The last line should be:

 ```
 You march into battle with your SWORD
 ```

 (or BOW). Type `RIGHT` and you take a nap instead.
 */

let path = console.read("Choose LEFT or RIGHT")
if path == "LEFT" {
    let weapon = console.read("You find some weapons. Choose SWORD or BOW")
} else {
    console.write("You take a nap under a tree.")
}
console.write("You march into battle with your " + weapon)
