//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 25: Three Doors
 ## What it should do
 Type `RED`, then `CHESS` or `TAG`: you get **only** a dragon ending. Type `GREEN`: **only** puppies. Type `BLUE`: **only** homework. Anything else: `That's not a door!` This one has **three** bugs!
 */

let door = console.read("Three doors! Choose RED, GREEN, or BLUE")
if door == "RED" {
    console.write("A dragon! It wants to play a game.")
}
let game = console.read("Choose CHESS or TAG")
if game == "CHESS" {
    console.write("The dragon wins in 4 moves. You're toast!")
} else {
    console.write("Dragons are terrible at tag. You win!")
}
if door == "GREEN" {
    console.write("A room full of puppies. Best ending!")
} else door == "BLUE" {
    console.write("A room full of homework. Oh no.")
} else {
    console.write("That's not a door!")
}
