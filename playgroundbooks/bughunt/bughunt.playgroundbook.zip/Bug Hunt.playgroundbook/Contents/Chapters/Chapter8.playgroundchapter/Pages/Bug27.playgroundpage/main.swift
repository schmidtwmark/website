//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 27
 ## What it should do
 **Challenge bug:** this one is extra tricky.

 Walk down 4 stairs to the flag. Each stair is 2 steps forward, then 1 step down.
 */

var stairs = 0
var steps = 0
while stairs < 4 {
    while steps < 2 {
        robot.forward()
        steps = steps + 1
    }
    robot.turnRight()
    robot.forward()
    robot.turnLeft()
    stairs = stairs + 1
}
