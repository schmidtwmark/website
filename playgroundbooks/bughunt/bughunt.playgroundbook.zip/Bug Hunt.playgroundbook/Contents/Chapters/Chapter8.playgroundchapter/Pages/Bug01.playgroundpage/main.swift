//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 1
 ## What it should do
 Say hello, ask for your name, and greet you by name. If you type `sam`, the last line should be:

 ```
 Nice to meet you, sam!
 ```
 */

console.write("Hello! I'm a computer.")
let name = console.read("What's your name?")
console.write("Nice to meet you, " + Name + "!")
