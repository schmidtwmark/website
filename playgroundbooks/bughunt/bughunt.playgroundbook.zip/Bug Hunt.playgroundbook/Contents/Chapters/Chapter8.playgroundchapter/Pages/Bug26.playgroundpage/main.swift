//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 26
 ## What it should do
 **Challenge bug:** this one is extra tricky.

 Type `LEFT`, then `SNEAK` or `FIGHT`, and you get a dragon ending. Type `RIGHT` and you find a beach.
 */

let path = console.read("Choose LEFT or RIGHT")
if path == "LEFT" {
    console.write("You find a sleeping dragon.")
    let dragonChoice = console.read("Choose SNEAK or FIGHT")
    if dragonChoice == "SNEAK" {
        console.write("You sneak past and grab the treasure!")
    } else if dragonChoice == "FIGHT" {
        console.write("The dragon wakes up. Run!")
    } else {
        console.write("You find a quiet beach. Nice!")
    }
}
