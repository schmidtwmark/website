//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 18
 ## What it should do
 Type `RED` and you find a dragon. Type anything else and you find gold.
 */

let door = console.read("Choose RED or BLUE")
if door == "RED" {
    console.write("A dragon is sleeping behind the red door.")
else {
    console.write("A pile of gold is behind the blue door!")
}
