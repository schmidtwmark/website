//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 11
 ## What it should do
 Drive to the end of the hall, turn right, and drive to the flag. This one has **two** bugs!
 */

while robot.facingEmptySpace() (
    robot.forward()
)
robot.turnRight{}
while robot.facingEmptySpace() {
    robot.forward()
}
