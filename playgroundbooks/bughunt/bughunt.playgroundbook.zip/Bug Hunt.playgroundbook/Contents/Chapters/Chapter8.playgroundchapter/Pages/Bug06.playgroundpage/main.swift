//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 6: Two Words
 ## What it should do
 Type `LEFT` and you walk into a forest. Type anything else and you walk into a village.
 */

let first choice = console.read("Choose LEFT or RIGHT")
if first choice == "LEFT" {
    console.write("You walk into a spooky forest.")
} else {
    console.write("You walk into a busy village.")
}
