//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 24: Adventure Mess
 ## What it should do
 Type `LEFT`, then `SNEAK`: you tiptoe past a bear. Type `LEFT`, then `RUN`: the bear wakes up. Type `RIGHT`: you find a lemonade stand. This one has **two** bugs!
 */

let path = console.read("Choose LEFT or RIGHT")
if path == "LEFT"
    console.write("You find a sleeping bear.")
    let bearChoice = console.read("Choose SNEAK or RUN")
    if bearchoice == "SNEAK" {
        console.write("You tiptoe past the bear. Safe!")
    } else {
        console.write("The bear wakes up. Run faster!")
    }
} else {
    console.write("You find a lemonade stand. Refreshing!")
}
