//#-hidden-code
import BookCore
import RobotAPI

let robot = robotConsole.robot()
//#-end-hidden-code
/*:
 # Bug 23: Hurdles
 ## What it should do
 Take 2 steps, jump the hurdle, and do that 3 times to reach the flag.
 */

func jumpHurdle() {
    robot.turnLeft()
    robot.forward()
    robot.turnRight()
    robot.forward()
    robot.forward()
    robot.turnRight()
    robot.forward()
    robot.turnLeft()
}

for _ in 1...3 {
    robot.forward()
    robot.forward()
}
