//#-hidden-code
import BookCore
import TextAPI
//#-end-hidden-code
/*:
 # Bug 16: Go Team!
 ## What it should do
 Cheer 3 times, then celebrate once. It should print:

 ```
 Go team!
 Go team!
 Go team!
 🎉 We win! 🎉
 ```
 */

var cheers = 0
while cheers < 3 {
    console.write("Go team!")
    cheers = cheers + 1
    console.write("🎉 We win! 🎉")
}
