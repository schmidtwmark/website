import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = RobotLiveViewController(level: .ascii("""
##########################
##...#...##...#...##...###
#>.#...#....#...#....#..*#
##########################
##########################
##########################
"""), par: 53)
