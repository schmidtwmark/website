//
//  See LICENSE folder for this template's licensing information.
//
//  Abstract:
//  Provides supporting functions for setting up a live view.
//

import UIKit
import PlaygroundSupport
import SwiftUI

public class TextLiveViewClient : LiveViewClient<TextCommand, TextResponse> {

    /**
     Write the provided string to the console
     */
    public func write(_ text: String) {
        sendCommand(TextCommand.write(text))
    }

    /**
     Write the provided colored string to the console.
     */
    public func write(_ coloredText: ColoredString) {
        sendCommand(TextCommand.writeColor(coloredText))
    }

    /**
     Write the provided prompt to the console, wait for the user to enter a response, return the response
     */
    public func read(_ prompt: String) -> String {
        let response = sendCommandAndWait(.read(prompt))
        if case let .submit(text) = response {
            return text
        } else {
            return ""
        }
    }
}

public class TurtleHandle {
    let liveViewClient: TurtleLiveViewClient
    let id: UUID

    init(liveViewClient: TurtleLiveViewClient, id: UUID) {
        self.liveViewClient = liveViewClient
        self.id = id
    }

    /**
     Move the turtle forward the specified distance
     */
    public func forward(_ distance: Double) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .forward(distance)))
    }

    /**
     Move the turtle backward the specified distance
     */
    public func backward(_ distance: Double) {
        forward(-distance)
    }

    /**
     Rotate the turtle by the provided number of degrees
     */
    public func rotate(_ angle: Double) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .rotate(angle)))
    }

    /**
     Move the turtle along an arc with provided radius for a given angle
     */
    public func arc(radius: Double, angle: Double) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .arc(radius, angle)))
    }

    /**
     Move the turtle along an elliptical arc with two radii for a given angle.
     `xRadius` is along the turtle's heading; `yRadius` is perpendicular
     (the distance from the turtle to the ellipse center).
     Passing the same value for both radii is equivalent to `arc(radius:angle:)`.
     */
    public func oval(xRadius: Double, yRadius: Double, angle: Double) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .oval(xRadius, yRadius, angle)))
    }

    /**
     Stop drawing lines
     */
    public func penUp() {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .penUp))
    }

    /**
     Draw a line that traces the path of the turtle. Optionally specify a color to fill
     */
    public func penDown(fillColor: Color = .clear) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .penDown(fillColor)))
    }

    /**
     Change the color of the line
     */
    public func lineColor(_ color: Color) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .lineColor(color)))
    }

    /**
     Change the width of the line
     */
    public func lineWidth(_ width: Double) {
        liveViewClient.sendCommandAndWait(.turtleAction(id, .lineWidth(width)))
    }

}

/// Base class for live view clients that communicate with the console via PlaygroundValue messages.
/// All methods run synchronously on the main thread using RunLoop spinning to wait for responses.
public class LiveViewClient<Request: ConsoleMessage, Response: ConsoleMessage> : PlaygroundRemoteLiveViewProxyDelegate {

    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundSupport.PlaygroundRemoteLiveViewProxy) {
    }

    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundSupport.PlaygroundRemoteLiveViewProxy, received message: PlaygroundSupport.PlaygroundValue) {
        guard let response = Response(message) else {
            return
        }
        responses.append(response)
    }

    func sendCommand(_ command: Request) {
        guard let liveViewMessageHandler = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            return
        }

        liveViewMessageHandler.send(command)
    }

    @discardableResult func sendCommandAndWait(_ command: Request) -> Response {
        guard let liveViewMessageHandler = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else {
            fatalError("Could not find live view")
        }

        liveViewMessageHandler.delegate = self
        liveViewMessageHandler.send(command)
        repeat {
            RunLoop.main.run(mode: .default, before: Date(timeIntervalSinceNow: 0.01))
        } while responses.count == 0

        return responses.remove(at: 0)
    }

    var responses: [Response] = []

    public init() { }
}

public class TurtleLiveViewClient : LiveViewClient<TurtleSceneCommand, TurtleSceneResponse> {

    /**
     Add a new turtle to the screen
     */
    public func addTurtle() -> TurtleHandle {
        let result = sendCommandAndWait(.addTurtle)
        if case .added(let id) = result {
            return TurtleHandle(liveViewClient: self, id: id)
        } else {
            fatalError("Failed to add turtle")
        }
    }
}

// MARK: - Robot Support

public class RobotHandle {
    let liveViewClient: RobotLiveViewClient

    init(liveViewClient: RobotLiveViewClient) {
        self.liveViewClient = liveViewClient
    }

    /**
     Move the robot forward one cell in its current direction
     */
    public func forward() {
        perform(.forward)
    }

    /**
     Rotate the robot 90 degrees to the right
     */
    public func turnRight() {
        perform(.turnRight)
    }

    /**
     Rotate the robot 90 degrees to the left
     */
    public func turnLeft() {
        perform(.turnLeft)
    }

    /**
     Wait one turn without moving (enemies and traps still advance)
     */
    public func wait() {
        perform(.wait)
    }

    /**
     True if the square right in front of the robot is a wall or the edge of the map.
     Looking does not use up a move.
     */
    public func facingWall() -> Bool {
        ask(.facingWall)
    }

    /**
     True if the square right in front of the robot is not a wall or the edge of the map:
     the exact opposite of `facingWall()`. Lets `while robot.facingEmptySpace() { robot.forward() }`
     be taught before `!`. Looking does not use up a move.
     */
    public func facingEmptySpace() -> Bool {
        !facingWall()
    }

    /**
     True if the robot is standing on the flag. Looking does not use up a move.
     */
    public func isOnGoal() -> Bool {
        ask(.isOnGoal)
    }

    /**
     True if there's a laser in the square right in front of the robot that is on, or about to
     turn on. `while robot.laserAhead() { robot.wait() }` waits until it's safe to step forward.
     Looking does not use up a move.
     */
    public func laserAhead() -> Bool {
        ask(.laserAhead)
    }

    private func perform(_ action: RobotAction) {
        switch liveViewClient.sendCommandAndWait(.robotAction(action)) {
        case .won, .actionFailed:
            // The level is over, so end the run. Loops like
            // `while !robot.isOnGoal()` stop at the flag or the crash
            // instead of spinning forever.
            PlaygroundPage.current.finishExecution()
        default:
            break
        }
    }

    private func ask(_ query: RobotQuery) -> Bool {
        if case .queryResult(let value) = liveViewClient.sendCommandAndWait(.query(query)) {
            return value
        }
        // Unexpected reply: answer so that a waiting loop stops instead of spinning.
        return query.stopLoopsAnswer
    }
}

public class RobotLiveViewClient : LiveViewClient<RobotSceneCommand, RobotSceneResponse> {

    /**
     Get a handle to control the robot (for pre-loaded levels)
     */
    public func robot() -> RobotHandle {
        let result = sendCommandAndWait(.getRobot)
        if case .robotReady = result {
            return RobotHandle(liveViewClient: self)
        } else {
            fatalError("Robot not ready - ensure level is pre-loaded in LiveView.swift")
        }
    }

    /**
     Load a level and return a handle to control the robot
     */
    public func loadLevel(_ level: Level) -> RobotHandle {
        let result = sendCommandAndWait(.loadLevel(level))
        if case .levelLoaded = result {
            return RobotHandle(liveViewClient: self)
        } else {
            fatalError("Failed to load level")
        }
    }

    /**
     Load a level from an ASCII string and return a handle to control the robot
     */
    @discardableResult
    public func loadLevel(_ ascii: String) -> RobotHandle {
        return loadLevel(Level.ascii(ascii))
    }

    /**
     Reset the current level to its initial state
     */
    public func reset() {
        sendCommandAndWait(.reset)
    }
}
