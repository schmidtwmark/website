//#-hidden-code
import BookCore
//#-end-hidden-code
/*:
 # Turtle Project
 Your turn!

 The **README** page lists every turtle command, including some these pages skipped: `turtle.backgroundColor(.black)` for a night sky, `turtle.home()` and `turtle.goTo(x: 100, y: 50)` to jump to a spot, `turtle.hideTurtle()` for a clean finished picture, `oval`, and custom colors such as `.hex("ff8800")`.
 */

let turtle = turtleConsole.addTurtle()
// Draw anything you want:
