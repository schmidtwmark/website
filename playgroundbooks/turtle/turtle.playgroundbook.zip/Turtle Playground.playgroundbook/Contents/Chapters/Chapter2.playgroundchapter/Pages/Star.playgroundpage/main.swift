//#-hidden-code
import BookCore
//#-end-hidden-code
/*:
 # Star
 ![An orange five-pointed star](star.png)

 Change how the pen looks *before* you put it down:

 ```
 turtle.lineColor(.purple)
 turtle.lineWidth(8)
 ```

 The normal width is 3. Try `.red`, `.orange`, `.yellow`, `.green`, `.pink` or `.black`.

 To make the star, you'll need to repeat the following code:
 
 ```
 turtle.forward(100)
 turtle.rotateRight(144)
 ```
 */

let turtle = turtleConsole.addTurtle()
// Write your code here:
