//#-hidden-code
import BookCore
//#-end-hidden-code
/*:
 # Square
 ![A blue square](square.png)

 Write code that makes the turtle draw the picture.

 The turtle starts facing right with its pen **up**, so call `turtle.penDown()` before it can draw. `turtle.forward(150)` moves 150 points. `turtle.rotateLeft(90)` turns left a quarter turn, and `turtle.rotateRight(90)` turns right.

 The square's sides are 150. Can you draw it with a `for` loop?
 */

let turtle = turtleConsole.addTurtle()
// Write your code here:
