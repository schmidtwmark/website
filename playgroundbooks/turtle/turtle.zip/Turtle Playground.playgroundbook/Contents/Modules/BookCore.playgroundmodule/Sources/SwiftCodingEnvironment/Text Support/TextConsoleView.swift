//
//  TextConsoleView.swift
//  StudentCodeTemplate
//
//  Created by Mark Schmidt on 11/16/24.
//

import SwiftUI
import Combine

public struct TextConsoleView: ConsoleView {
    public init(console: TextConsole) {
        self.console = console
    }
    
    
    @ObservedObject var console: TextConsole
    @FocusState private var isTextFieldFocused: Bool
    private var textSize: Font.TextStyle {
        textSizes[textSizeIndex]
    }
    @State
    private var textSizeIndex: Int = 0
    
    let textSizes : [Font.TextStyle] = [.body, .title3, .title2, .title, .largeTitle]

    public var body: some View {
        ScrollView {
            HStack {
                LazyVStack (alignment: .leading, spacing: 0.0) {
                    ForEach(console.lines) { line in
                        VStack {
                            switch line.content {
                            case .output(let text):
                                Text(text)
                                    .lineLimit(nil)
                            case .input:
                                TextField("", text: $console.userInput)
                                    .onSubmit {
                                        console.submitInput(true)
                                    }
                                    .focused($isTextFieldFocused)
                            }
                        }
                    }
                }
                Spacer()
            }
            .font(.system(textSize, design: .monospaced))
            .padding()
        }
        .overlay(alignment: .topTrailing) {
            HStack {
                Button(action: {
                    withAnimation {
                        textSizeIndex = (textSizeIndex - 1) % textSizes.count
                    }
                }) {
                    Label("Minus", systemImage: "minus")
                        .padding()
                }
                .contentShape(Rectangle())
                .disabled(textSizeIndex == 0)
                Label("Aa", systemImage: "textformat.size")
                Button(action: {
                    withAnimation {
                        textSizeIndex = (textSizeIndex + 1) % textSizes.count
                    }
                }) {
                    Label("Plus", systemImage: "plus")
                        .padding()
                }
                .contentShape(Rectangle())
                .disabled(textSizeIndex == textSizes.count - 1)
            }
            .labelStyle(.iconOnly)
            .font(.title2)
            .background(Capsule().fill(Color.gray.opacity(0.1)))
            .clipShape(Capsule())
            .overlay(
                Capsule()
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
            .padding()
        }
        .defaultScrollAnchor(.bottom)
        .scrollIndicators(.visible)
        .task {
            console.setFocus = { focus in
                isTextFieldFocused = focus
            }
        }
    }
    
}
