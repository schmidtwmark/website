//
//  ContentView.swift
//  Wordle
//
//  Created by Mark Schmidt on 9/21/24.
//

import SwiftUI

struct ContentView: View {

    
    var body: some View {
        VStack {
            // TODO: create the Wordle game
        }
    }
}


#Preview {
    ContentView()
}
