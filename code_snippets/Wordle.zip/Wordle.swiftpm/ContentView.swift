import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            // TODO: create the Wordle game
        }
    }
}
