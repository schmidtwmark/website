import SwiftUI

struct ContentView: View {
    
    @State var pressCount = 0
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Group {
                    Text("Mark Schmidt").font(.largeTitle)
                    Image("luna")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                    Text("This is Luna--the best dog in the whole world and my all-time favorite. She is everybody's best friend!")
                }
                
                Group {
                    Spacer(minLength: 40.0)
                    Image("book").resizable().aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                    Text("My favorite book is Tomorrow and Tomorrow and Tomorrow by Gabrielle Zevin. It is a beautiful story of two flawed people making art together")
                }
                
                Group {
                    
                    Spacer(minLength: 40.0)
                    Image("overwatch")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                    Text("My favorite video game is Overwatch 2! I'm a Zarya/Roadhog main. Peaked at Master rank in Overwatch 1 but I don't really do competitive anymore.")
                }
                
                Group {
                    Spacer(minLength: 40.0)
                    Image("rust")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                    Text("Rust is my favorite programming language. Rust has so many features that help developers write fast, bug-free code")
                }
                
                Group {
                    Spacer(minLength: 40.0)
                    Image("taylor")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                    Text("I have a few all time favorite musicians, but it's so hard not to love Taylor Swift. She's an incredible performer and songwriter. Folklore and Evermore are her best albums")
                }
                
            }.padding(20)
        }
    }
}
