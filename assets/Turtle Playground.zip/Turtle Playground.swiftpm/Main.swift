import SwiftCodingEnvironment

func start(console: TurtleConsole) {

}
