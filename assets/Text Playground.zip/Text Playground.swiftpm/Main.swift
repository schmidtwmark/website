import SwiftCodingEnvironment

func start(console: TextConsole) {

}
