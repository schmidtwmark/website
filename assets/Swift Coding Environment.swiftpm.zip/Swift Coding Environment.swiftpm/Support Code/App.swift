 import SwiftUI

@main
struct StudentCodeTemplateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView<TextConsole, TextConsoleView>()
        }
    }
}
